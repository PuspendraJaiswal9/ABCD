import React from "react";
import { Link } from "react-router-dom";

function Header() {
  return (
    <header className="header">
      <h1>AI Blog Generator</h1>
      <nav>
        <Link to="/">Login</Link>
        <Link to="/register">Register</Link>
        <Link to="/generate">Generate Blog</Link>
        <Link to="/history">My Blogs</Link>
      </nav>
    </header>
  );
}

export default Header;
