import React, { useState } from "react";
import { generateBlog } from "../api";

function BlogGenerator() {
  const [username, setUsername] = useState("");
  const [keywords, setKeywords] = useState("");
  const [tone, setTone] = useState("");
  const [length, setLength] = useState("");
  const [generatedBlog, setGeneratedBlog] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await generateBlog({ username, keywords, tone, length });
      setGeneratedBlog(res.data.generatedBlog);
    } catch (err) {
      setGeneratedBlog("Error generating blog");
    }
  };

  return (
    <div className="form-container">
      <h2>Generate Blog</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" placeholder="Username" value={username} onChange={(e)=>setUsername(e.target.value)} required />
        <input type="text" placeholder="Keywords" value={keywords} onChange={(e)=>setKeywords(e.target.value)} required />
        <input type="text" placeholder="Tone" value={tone} onChange={(e)=>setTone(e.target.value)} required />
        <input type="text" placeholder="Length" value={length} onChange={(e)=>setLength(e.target.value)} required />
        <button type="submit">Generate</button>
      </form>
      {generatedBlog && (
        <div className="blog-output">
          <h3>Generated Blog:</h3>
          <p>{generatedBlog}</p>
        </div>
      )}
    </div>
  );
}

export default BlogGenerator;
