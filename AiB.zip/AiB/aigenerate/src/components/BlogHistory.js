import React, { useState } from "react";
import { getUserBlogs } from "../api";

function BlogHistory() {
  const [username, setUsername] = useState("");
  const [blogs, setBlogs] = useState([]);

  const handleFetch = async () => {
    try {
      const res = await getUserBlogs(username);
      setBlogs(res.data);
    } catch (err) {
      setBlogs([]);
    }
  };

  return (
    <div className="form-container">
      <h2>My Blog History</h2>
      <input type="text" placeholder="Username" value={username} onChange={(e)=>setUsername(e.target.value)} />
      <button onClick={handleFetch}>Fetch Blogs</button>
      <div className="blog-history">
        {blogs.map((b) => (
          <div key={b.id} className="blog-card">
            <p><strong>Keywords:</strong> {b.keywords}</p>
            <p><strong>Tone:</strong> {b.tone}</p>
            <p><strong>Length:</strong> {b.length}</p>
            <p>{b.generatedBlog}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default BlogHistory;
