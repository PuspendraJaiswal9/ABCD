import React from "react";
import { Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Login from "./components/Login";
import Register from "./components/Register";
import BlogGenerator from "./components/BlogGenerator";
import BlogHistory from "./components/BlogHistory";

function App() {
  return (
    <div>
      <Header />
      <div className="container">
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/generate" element={<BlogGenerator />} />
          <Route path="/history" element={<BlogHistory />} />
        </Routes>
      </div>
      <Footer />
    </div>
  );
}

export default App;
