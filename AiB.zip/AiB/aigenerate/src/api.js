import axios from "axios";

const API_BASE = "http://localhost:8080";

export const registerUser = (data) => axios.post(`${API_BASE}/auth/register`, data);
export const loginUser = (data) => axios.post(`${API_BASE}/auth/login`, data);
export const generateBlog = (data) => axios.post(`${API_BASE}/blog/generate`, data);
export const getUserBlogs = (username) => axios.get(`${API_BASE}/blog/history/${username}`);
