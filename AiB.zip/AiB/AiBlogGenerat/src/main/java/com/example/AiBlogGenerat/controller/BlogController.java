package com.example.AiBlogGenerat.controller;

import com.example.AiBlogGenerat.entity.BlogRequest;
import com.example.AiBlogGenerat.service.BlogService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/blog")
@CrossOrigin(origins = "http://localhost:3000")
public class BlogController {

    private final BlogService blogService;

    public BlogController(BlogService blogService) {
        this.blogService = blogService;
    }

    @PostMapping("/generate")
    public BlogRequest generateBlog(@RequestBody Map<String, String> body) {
        String username = body.get("username");
        String keywords = body.get("keywords");
        String tone = body.get("tone");
        String length = body.get("length");

        return blogService.generateBlog(username, keywords, tone, length);
    }

    @GetMapping("/history/{username}")
    public List<BlogRequest> getHistory(@PathVariable String username) {
        return blogService.getUserBlogs(username);
    }
}

