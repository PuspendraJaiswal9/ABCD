package com.example.AiBlogGenerat.service;

import com.example.AiBlogGenerat.entity.BlogRequest;
import com.example.AiBlogGenerat.repository.BlogRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.List;
import java.util.Map;

@FeignClient(name = "azure-openai-client", url = "${azure.openai.endpoint}")
interface AzureOpenAIClient {
    @PostMapping("/openai/deployments/{deploymentName}/chat/completions?api-version=2023-03-15-preview")
    Map<String, Object> sendRequest(
            @PathVariable("deploymentName") String deploymentName,
            @RequestBody Map<String, Object> body,
            @RequestHeader("api-key") String apiKey
    );
}

@Service
public class BlogService {

    private final BlogRepository blogRepository;
    private final AzureOpenAIClient azureClient;

    @Value("${azure.openai.key}")
    private String apiKey;

    @Value("${azure.openai.deployment-name}")
    private String deploymentName;

    public BlogService(BlogRepository blogRepository, AzureOpenAIClient azureClient) {
        this.blogRepository = blogRepository;
        this.azureClient = azureClient;
    }

    public BlogRequest generateBlog(String username, String keywords, String tone, String length) {
        String prompt = String.format("Write a %s, %s tone, SEO-optimized blog about: %s", length, tone, keywords);

        Map<String, Object> body = Map.of(
                "messages", List.of(Map.of("role", "user", "content", prompt)),
                "max_tokens", 500,
                "temperature", 0.7
        );

        Map<String, Object> response = azureClient.sendRequest(deploymentName, body, apiKey);

        List<Map> choices = (List<Map>) response.get("choices");
        Map message = (Map) ((Map) choices.get(0)).get("message");
        String content = message.get("content").toString();

        BlogRequest blog = new BlogRequest(username, keywords, tone, length, content);
        return blogRepository.save(blog);
    }

    public List<BlogRequest> getUserBlogs(String username) {
        return blogRepository.findByUsername(username);
    }
}
