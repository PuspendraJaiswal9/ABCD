package com.example.AiBlogGenerat.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "generated_blogs")
public class BlogRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;
    private String keywords;
    private String tone;
    private String length;
    @Column(columnDefinition = "LONGTEXT")
    private String generatedBlog;

    public BlogRequest() {}

    public BlogRequest(String username, String keywords, String tone, String length, String generatedBlog) {
        this.username = username;
        this.keywords = keywords;
        this.tone = tone;
        this.length = length;
        this.generatedBlog = generatedBlog;
    }

    public Long getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public String getTone() {
        return tone;
    }

    public void setTone(String tone) {
        this.tone = tone;
    }

    public String getLength() {
        return length;
    }

    public void setLength(String length) {
        this.length = length;
    }

    public String getGeneratedBlog() {
        return generatedBlog;
    }

    public void setGeneratedBlog(String generatedBlog) {
        this.generatedBlog = generatedBlog;
    }
}

