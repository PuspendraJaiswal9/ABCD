package com.example.AiBlogGenerat.controller;

import com.example.AiBlogGenerat.service.UserService;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "http://localhost:3000")
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/register")
    public Map<String, String> register(@RequestBody Map<String, String> body) {
        String username = body.get("username");
        String password = body.get("password");
        userService.registerUser(username, password);
        return Map.of("message", "User registered successfully");
    }

    @PostMapping("/login")
    public Map<String, String> login(@RequestBody Map<String, String> body) {
        String username = body.get("username");
        String password = body.get("password");
        boolean authenticated = userService.authenticate(username, password);
        if (authenticated) {
            return Map.of("message", "Login successful");
        } else {
            return Map.of("message", "Invalid credentials");
        }
    }
}

