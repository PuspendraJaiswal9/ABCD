package com.example.AiBlogGenerat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiBlogGeneratApplicationTests {

	@Test
	void contextLoads() {
	}

}
