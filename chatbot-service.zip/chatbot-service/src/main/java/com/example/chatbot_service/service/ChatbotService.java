package com.example.chatbot_service.service;

import com.example.chatbot_service.dto.Booking;
import com.example.chatbot_service.dto.Fare;
import com.example.chatbot_service.dto.Workshop;
import com.example.chatbot_service.entity.ChatHistory;
import com.example.chatbot_service.entity.Ticket;
import com.example.chatbot_service.entity.Users;
import com.example.chatbot_service.feingClient.BookingClient;
import com.example.chatbot_service.feingClient.FareClient;
import com.example.chatbot_service.feingClient.WorkshopClient;
import com.example.chatbot_service.repository.ChatHistoryRepository;
import com.example.chatbot_service.repository.TicketRepository;
import com.example.chatbot_service.repository.UsersRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class ChatbotService {

    @Value("${azure.openai.key}")
    private String apiKey;

    private final AzureOpenAIClient azureClient;
    private final String deploymentName;

    private final WorkshopClient workshopClient;
    private final FareClient fareClient;
    private final BookingClient bookingClient;

    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private TicketRepository ticketRepository;

    @Autowired
    private ChatHistoryRepository chatHistoryRepository;

    public ChatbotService(AzureOpenAIClient azureClient,
                          @Value("${azure.openai.deployment-name}") String deploymentName,
                          WorkshopClient workshopClient,
                          FareClient fareClient,
                          BookingClient bookingClient) {
        this.azureClient = azureClient;
        this.deploymentName = deploymentName;
        this.workshopClient = workshopClient;
        this.fareClient = fareClient;
        this.bookingClient = bookingClient;
    }

    public String getChatResponse(Long userId, String userMessage) {
        Users user = usersRepository.findById(userId).orElseGet(() -> {
            Users newUser = new Users();
            newUser.setName("User" + userId);
            newUser.setEmail("user" + userId + "@example.com");
            return usersRepository.save(newUser);
        });

        String message = userMessage.toLowerCase();
        String response = "";

        // ✅ Greeting
        if (message.contains("hello") || message.contains("hi") || message.contains("hey")) {
            response = "Hello " + user.getName() + "! How can I assist you today?";
        }

        // ✅ FAQ handling
        else if (message.contains("faq") || message.contains("how to") || message.contains("information")) {
            response = "You can ask about booking, fare, workshops, or raise a ticket for issues.";
        }

        // ✅ Ticket status check (priority upar rakho)
        else if ((message.contains("ticket") && message.contains("status")) || message.contains("check ticket")) {
            List<Ticket> tickets = ticketRepository.findByUserId(user.getId());
            if (tickets.isEmpty()) {
                response = "You don’t have any active tickets right now.";
            } else {
                Ticket last = tickets.get(tickets.size() - 1);
                response = "Your last ticket (ID: " + last.getId() + ") is currently " + last.getStatus() + ".";
            }
        }

        // ✅ Live agent request
        else if (message.contains("human") || message.contains("live agent") || message.contains("talk to agent")) {
            Ticket ticket = new Ticket();
            ticket.setUserId(user.getId());
            ticket.setSubject("Live Agent Request");
            ticket.setDescription(userMessage);
            ticket.setStatus("PENDING_AGENT");
            ticket.setCreatedAt(LocalDateTime.now());
            ticket.setUpdatedAt(LocalDateTime.now());
            ticketRepository.save(ticket);
            response = "Connecting you to a live support agent... Ticket ID: " + ticket.getId();
        }

        // ✅ Ticket creation only for real problems (exclude status check)
        else if ((message.contains("problem") || message.contains("issue") || message.contains("error") || message.contains("not working"))
                && !message.contains("status")) {
            Ticket ticket = new Ticket();
            ticket.setUserId(user.getId());
            ticket.setSubject("Support Issue");
            ticket.setDescription(userMessage);
            ticket.setStatus("OPEN");
            ticket.setCreatedAt(LocalDateTime.now());
            ticket.setUpdatedAt(LocalDateTime.now());
            ticketRepository.save(ticket);
            response = "I understand you're facing an issue. A support ticket has been created successfully! Ticket ID: " + ticket.getId() + ". Our team will get back to you soon.";
        }

        // ✅ Workshop info
        else if (message.contains("workshop")) {
            try {
                Long workshopId = Long.parseLong(message.replaceAll("[^0-9]", ""));
                Workshop workshop = workshopClient.getWorkshopById(workshopId);
                if (workshop != null) {
                    response = "Workshop Info: Title - " + workshop.getTitle()
                            + ", Date - " + workshop.getDate()
                            + ", Venue - " + workshop.getVenue()
                            + ", Available Seats - " + workshop.getAvailableSeats();
                }
            } catch (Exception ignored) {}
        }

        // ✅ Fare info
        else if (message.contains("fare")) {
            try {
                Long fareId = Long.parseLong(message.replaceAll("[^0-9]", ""));
                Fare fare = fareClient.getFareById(fareId);
                if (fare != null) {
                    response = "Fare Info: Price - " + fare.getPrice();
                }
            } catch (Exception ignored) {}
        }

        // ✅ Booking info
        else if (message.contains("booking")) {
            try {
                Long bookingId = Long.parseLong(message.replaceAll("[^0-9]", ""));
                Optional<Booking> bookingOpt = bookingClient.getBookingById(bookingId);
                if (bookingOpt.isPresent()) {
                    Booking booking = bookingOpt.get();
                    response = "Booking Info: Name - " + booking.getName()
                            + ", WorkshopId - " + booking.getWorkshopId()
                            + ", Number of Booking - " + booking.getNumberOfBooking()
                            + ", Status - " + booking.getStatus();
                }
            } catch (Exception ignored) {}
        }

        // ✅ AI fallback
        else {
            Map<String, Object> requestBody = Map.of(
                    "messages", List.of(Map.of("role", "user", "content", userMessage)),
                    "max_tokens", 200,
                    "temperature", 0.7
            );
            Map<String, Object> aiResponse = azureClient.sendRequest(deploymentName, requestBody, apiKey);
            if (aiResponse != null && aiResponse.containsKey("choices")) {
                Map firstChoice = ((List<Map>) aiResponse.get("choices")).get(0);
                Map msg = (Map) firstChoice.get("message");
                response = msg.get("content").toString();
            } else {
                response = "Sorry, I couldn’t understand your message.";
            }
        }

        ChatHistory chat = new ChatHistory();
        chat.setUserId(user.getId());
        chat.setMessage(userMessage);
        chat.setResponse(response);
        chat.setCreatedAt(LocalDateTime.now());
        chatHistoryRepository.save(chat);

        return response;
    }


}
